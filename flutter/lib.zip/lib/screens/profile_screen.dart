// lib/screens/profile_screen.dart
import 'dart:typed_data';
import 'seller_registration/seller_type_screen.dart';
import 'seller_registration/seller_company_info_screen.dart';
import 'seller_registration/seller_registration_provider.dart';
import 'seller_registration/seller_registration_service.dart';
import 'seller_company_form_screen.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../l10n/app_localizations.dart';

import '../providers/auth_provider.dart';
import '../providers/favorite_provider.dart';
import '../providers/cart_provider.dart';
import '../providers/locale_provider.dart';
import '../services/api_service.dart';

import 'login_screen.dart';
import 'register_screen.dart';
import 'cart_screen.dart';
import 'purchases_screen.dart';
import 'favorite_screen.dart';
import 'seller_main_screen.dart';
import 'my_reviews_screen.dart';


class ProfileScreen extends StatefulWidget {
  final bool showSellerPanelEntry;
  final bool sellerMode;

  const ProfileScreen({
    super.key,
    this.showSellerPanelEntry = true,
    this.sellerMode = false,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with WidgetsBindingObserver {
  static const Color accentColor = Color(0xFFD1BC00);

  late Future<Map<String, dynamic>> _profileFuture;
  late Future<Map<String, dynamic>?> _sellerApplicationFuture;

  final ImagePicker _profileImagePicker = ImagePicker();
  XFile? _avatarOriginalImage;
  XFile? _avatarCroppedFile;
  Uint8List? _avatarPreviewBytes;
  String _avatarPreviewFileName = 'avatar.jpg';
  bool _avatarUploading = false;


  Future<Map<String, dynamic>> _safeGetProfile() async {
    final isLoggedIn = await ApiService.isLoggedIn();

    if (!isLoggedIn) {
      return <String, dynamic>{};
    }

    try {
      return await ApiService.getProfile();
    } catch (_) {
      return <String, dynamic>{};
    }
  }


  SellerRegistrationService _sellerRegistrationService() {
    return SellerRegistrationService(
      dio: Dio(
        BaseOptions(
          connectTimeout: const Duration(seconds: 15),
          receiveTimeout: const Duration(seconds: 30),
        ),
      ),
      baseUrl: ApiService.apiUrl,
    );
  }

  Future<Map<String, dynamic>?> _safeGetSellerApplication() async {
    final isLoggedIn = await ApiService.isLoggedIn();
    if (!isLoggedIn) return null;
    try {
      return await _sellerRegistrationService().getMyApplication();
    } catch (_) {
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _profileFuture = _safeGetProfile();
    _sellerApplicationFuture = _safeGetSellerApplication();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = context.read<AuthProvider>();
      if (auth.isLoggedIn) {
        context.read<CartProvider>().loadCart(silent: true);
        context.read<FavoriteProvider>().loadFavorites();
      }
    });
  }

  void _reloadProfile() {
    if (!mounted) return;
    setState(() {
      _profileFuture = _safeGetProfile();
      _sellerApplicationFuture = _safeGetSellerApplication();
    });
  }

  Future<void> _refreshProfileData() async {
    if (!mounted) return;

    await context.read<AuthProvider>().checkLoginStatus();
    if (!mounted) return;

    final profileFuture = _safeGetProfile();
    final applicationFuture = _safeGetSellerApplication();

    setState(() {
      _profileFuture = profileFuture;
      _sellerApplicationFuture = applicationFuture;
    });

    await Future.wait<dynamic>([
      profileFuture,
      applicationFuture,
    ]);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _refreshProfileData();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _logout(BuildContext context) async {
    await context.read<AuthProvider>().logout();
    await context.read<FavoriteProvider>().loadFavorites();

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppLocalizations.of(context)!.logoutSuccess)),
      );
    }
  }

  void _openCart(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const CartScreen()),
    );
  }

  void _openPurchases(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PurchasesScreen()),
    );
  }

  void _openMyReviews(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const MyReviewsScreen(),
      ),
    );
  }

  void _openFavorites(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const FavoriteScreen()),
    );
  }

  void _openSellerDashboard(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const SellerMainScreen(
          profileScreen: ProfileScreen(
            showSellerPanelEntry: false,
            sellerMode: true,
          ),
        ),
      ),
    );
  }

  Future<void> _openSellerCompanySettings(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const SellerCompanyFormScreen(),
      ),
    );

    if (mounted) {
      await _refreshProfileData();
    }
  }

  Future<void> _openSellerRegistration(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const SellerTypeScreen(),
      ),
    );

    if (mounted) {
      await _refreshProfileData();
    }
  }


  Future<void> _openSellerApplication(
      BuildContext context,
      Map<String, dynamic> application,
      ) async {
    if (application['is_editable'] != true) return;

    try {
      final service = _sellerRegistrationService();
      final channelCodes =
      await service.resolveApplicationChannelCodes(application);
      final provider = SellerRegistrationProvider()
        ..loadFromApplication(
          application,
          channelCodes: channelCodes,
        );

      if (!context.mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ChangeNotifierProvider.value(
            value: provider,
            child: const SellerCompanyInfoScreen(),
          ),
        ),
      );
      if (mounted) _reloadProfile();
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РєСЂС‹С‚СЊ Р·Р°СЏРІРєСѓ: $error'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _openLogin(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );

    if (result == true && context.mounted) {
      await context.read<AuthProvider>().checkLoginStatus();
      await context.read<FavoriteProvider>().loadFavorites();
      await context.read<CartProvider>().loadCart();
      _reloadProfile();
    }
  }

  void _openRegister(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const RegisterScreen()),
    );

    if (result == true && context.mounted) {
      await context.read<AuthProvider>().checkLoginStatus();
      _reloadProfile();
    }
  }

  String _avatarText({
    required String ru,
    required String en,
    required String hy,
  }) {
    return switch (Localizations.localeOf(context).languageCode) {
      'ru' => ru,
      'hy' => hy,
      _ => en,
    };
  }

  String _clientPhoneDigits(dynamic value) {
    return value?.toString().replaceAll(RegExp(r'\D'), '') ?? '';
  }

  String _normalizeClientPhone(dynamic value) {
    final digits = _clientPhoneDigits(value);
    return digits.isEmpty ? '' : '+$digits';
  }

  Future<bool> _confirmDiscardProfileChanges(BuildContext dialogContext) async {
    if (!mounted) return false;

    final discard = await showDialog<bool>(
      context: dialogContext,
      builder: (confirmContext) {
        return AlertDialog(
          title: Text(
            _avatarText(
              ru: 'Есть несохранённые изменения',
              en: 'Unsaved changes',
              hy: 'Կան չպահպանված փոփոխություններ',
            ),
          ),
          content: Text(
            _avatarText(
              ru: 'Выйти без сохранения изменений?',
              en: 'Leave without saving your changes?',
              hy: 'Դուրս գալ առանց փոփոխությունները պահպանելու՞',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(confirmContext).pop(false),
              child: Text(
                _avatarText(
                  ru: 'Остаться',
                  en: 'Stay',
                  hy: 'Մնալ',
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(confirmContext).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                foregroundColor: Colors.white,
                elevation: 0,
              ),
              child: Text(
                _avatarText(
                  ru: 'Выйти',
                  en: 'Leave',
                  hy: 'Դուրս գալ',
                ),
              ),
            ),
          ],
        );
      },
    );

    return discard ?? false;
  }

  Future<void> _showAvatarSourceMenu() async {
    if (_avatarUploading) return;

    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 42,
                  height: 5,
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: Colors.black12,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
                ListTile(
                  leading: const Icon(
                    Icons.photo_camera_outlined,
                    color: accentColor,
                  ),
                  title: Text(
                    _avatarText(
                      ru: 'Сделать фото',
                      en: 'Take photo',
                      hy: 'Լուսանկարել',
                    ),
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  onTap: () => Navigator.of(sheetContext).pop(
                    ImageSource.camera,
                  ),
                ),
                ListTile(
                  leading: const Icon(
                    Icons.photo_library_outlined,
                    color: accentColor,
                  ),
                  title: Text(
                    _avatarText(
                      ru: 'Выбрать из галереи',
                      en: 'Choose from gallery',
                      hy: 'Ընտրել պատկերասրահից',
                    ),
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  onTap: () => Navigator.of(sheetContext).pop(
                    ImageSource.gallery,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (source == null || !mounted) return;
    await _pickProfileAvatar(source);
  }

  Future<void> _pickProfileAvatar(ImageSource source) async {
    final image = await _profileImagePicker.pickImage(
      source: source,
      imageQuality: 85,
      maxWidth: 1600,
      maxHeight: 1600,
    );

    if (image == null || !mounted) return;

    _avatarOriginalImage = image;

    final cropOk = await _cropProfileAvatar(image);
    if (!cropOk || !mounted) {
      _clearPendingAvatarPreview();
      return;
    }

    await _showAvatarPreviewActions();
  }

  Future<bool> _cropProfileAvatar(XFile sourceImage) async {
    if (!mounted) return false;

    final cropped = await ImageCropper().cropImage(
      sourcePath: sourceImage.path,
      aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
      compressFormat: ImageCompressFormat.jpg,
      compressQuality: 92,
      maxWidth: 1200,
      maxHeight: 1200,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: _avatarText(
            ru: 'Кадрирование аватара',
            en: 'Crop avatar',
            hy: 'Ավատարի կադրավորում',
          ),
          toolbarColor: Colors.white,
          toolbarWidgetColor: Colors.black,
          activeControlsWidgetColor: accentColor,
          statusBarLight: true,
          navBarLight: true,
          lockAspectRatio: true,
          hideBottomControls: true,
          showCropGrid: false,
          cropStyle: CropStyle.circle,
          dimmedLayerColor: Colors.black,
          cropFrameColor: Colors.white,
          cropFrameStrokeWidth: 2,
        ),
        IOSUiSettings(
          title: _avatarText(
            ru: 'Кадрирование аватара',
            en: 'Crop avatar',
            hy: 'Ավատարի կադրավորում',
          ),
          doneButtonTitle: _avatarText(
            ru: 'Готово',
            en: 'Done',
            hy: 'Պատրաստ',
          ),
          cancelButtonTitle: _avatarText(
            ru: 'Отмена',
            en: 'Cancel',
            hy: 'Չեղարկել',
          ),
          aspectRatioLockEnabled: true,
          resetAspectRatioEnabled: false,
          aspectRatioPickerButtonHidden: true,
          cropStyle: CropStyle.circle,
        ),
        WebUiSettings(context: context),
      ],
    );

    if (cropped == null || !mounted) return false;

    final croppedFile = XFile(cropped.path);
    final bytes = await croppedFile.readAsBytes();

    if (!mounted) return false;

    setState(() {
      _avatarCroppedFile = croppedFile;
      _avatarPreviewBytes = bytes;
      _avatarPreviewFileName = 'avatar.jpg';
    });

    return true;
  }

  Future<void> _showAvatarPreviewActions() async {
    while (mounted && _avatarPreviewBytes != null) {
      final action = await showModalBottomSheet<String>(
        context: context,
        isDismissible: false,
        enableDrag: false,
        backgroundColor: Colors.transparent,
        builder: (sheetContext) {
          return WillPopScope(
            onWillPop: () async {
              return _confirmDiscardProfileChanges(sheetContext);
            },
            child: SafeArea(
              top: false,
              child: Container(
                margin: const EdgeInsets.all(12),
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(28),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 42,
                      height: 5,
                      decoration: BoxDecoration(
                        color: Colors.black12,
                        borderRadius: BorderRadius.circular(999),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _avatarText(
                        ru: 'Как будет выглядеть фото',
                        en: 'How your photo will look',
                        hy: 'Ինչպես կերևա լուսանկարը',
                      ),
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: 168,
                      height: 168,
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: accentColor,
                          width: 2,
                        ),
                      ),
                      child: ClipOval(
                        child: Image.memory(
                          _avatarPreviewBytes!,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: OutlinedButton.icon(
                        onPressed: () =>
                            Navigator.of(sheetContext).pop('edit'),
                        icon: const Icon(Icons.crop_rounded),
                        label: Text(
                          _avatarText(
                            ru: 'Редактировать фото',
                            en: 'Edit photo',
                            hy: 'Խմբագրել լուսանկարը',
                          ),
                        ),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.black87,
                          side: const BorderSide(color: accentColor),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: () =>
                            Navigator.of(sheetContext).pop('save'),
                        icon: const Icon(Icons.check_rounded),
                        label: Text(
                          _avatarText(
                            ru: 'Сохранить',
                            en: 'Save',
                            hy: 'Պահպանել',
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: accentColor,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextButton(
                      onPressed: () async {
                        final discard =
                        await _confirmDiscardProfileChanges(sheetContext);
                        if (!discard || !sheetContext.mounted) return;
                        Navigator.of(sheetContext).pop('discard');
                      },
                      child: Text(
                        _avatarText(
                          ru: 'Отменить',
                          en: 'Cancel',
                          hy: 'Չեղարկել',
                        ),
                        style: const TextStyle(
                          color: Color(0xFF777777),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );

      if (!mounted) return;

      if (action == 'edit') {
        final original = _avatarOriginalImage;
        if (original == null) {
          _clearPendingAvatarPreview();
          return;
        }

        final ok = await _cropProfileAvatar(original);
        if (!ok || !mounted) {
          _clearPendingAvatarPreview();
          return;
        }
        continue;
      }

      if (action == 'save') {
        await _uploadPendingAvatar();
        return;
      }

      // Cancel/back after confirmation: keep the existing saved avatar unchanged.
      _clearPendingAvatarPreview();
      return;
    }
  }

  Future<void> _uploadPendingAvatar() async {
    final bytes = _avatarPreviewBytes;
    if (bytes == null || _avatarUploading) return;

    setState(() => _avatarUploading = true);

    try {
      final updatedProfile = await ApiService.updateProfileAvatar(
        avatarBytes: bytes,
        fileName: _avatarPreviewFileName,
      );

      if (!mounted) return;

      setState(() {
        _avatarUploading = false;
        _avatarPreviewBytes = null;
        _avatarOriginalImage = null;
        _avatarCroppedFile = null;
        _profileFuture = Future.value(updatedProfile);
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _avatarText(
              ru: 'Фото профиля сохранено',
              en: 'Profile photo saved',
              hy: 'Պրոֆիլի լուսանկարը պահպանված է',
            ),
          ),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (_) {
      if (!mounted) return;

      setState(() => _avatarUploading = false);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _avatarText(
              ru: 'Не удалось сохранить фото профиля',
              en: 'Could not save profile photo',
              hy: 'Չհաջողվեց պահպանել պրոֆիլի լուսանկարը',
            ),
          ),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _clearPendingAvatarPreview() {
    if (!mounted) return;
    setState(() {
      _avatarOriginalImage = null;
      _avatarCroppedFile = null;
      _avatarPreviewBytes = null;
    });
  }

  String _profileAvatarUrl(Map<String, dynamic> profile) {
    final candidates = [
      profile['avatar_url'],
      profile['avatar'],
      profile['image_url'],
    ];

    for (final value in candidates) {
      final raw = value?.toString().trim() ?? '';
      if (raw.isNotEmpty) return ApiService.fixImageUrl(raw);
    }

    return '';
  }

  Widget _buildProfileAvatar(Map<String, dynamic> profile) {
    final avatarUrl = _profileAvatarUrl(profile);

    Widget image;

    if (_avatarPreviewBytes != null) {
      image = Image.memory(
        _avatarPreviewBytes!,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
      );
    } else if (avatarUrl.isNotEmpty) {
      image = Image.network(
        avatarUrl,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (_, _, _) => const Icon(
          Icons.person_rounded,
          size: 46,
          color: Color(0xFF777777),
        ),
      );
    } else {
      image = const Icon(
        Icons.person_rounded,
        size: 46,
        color: Color(0xFF777777),
      );
    }

    return SizedBox(
      width: 104,
      height: 104,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: 104,
            height: 104,
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border: Border.all(
                color: accentColor,
                width: 1.4,
              ),
            ),
            child: ClipOval(
              child: Container(
                color: const Color(0xFFF1EFF3),
                child: image,
              ),
            ),
          ),
          if (_avatarUploading)
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.62),
                  shape: BoxShape.circle,
                ),
                child: const Center(
                  child: SizedBox(
                    width: 25,
                    height: 25,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: accentColor,
                    ),
                  ),
                ),
              ),
            ),

          // Separate replacement button. The saved/old avatar itself is not
          // re-editable; this button starts Camera / Gallery.
          Positioned(
            right: -2,
            bottom: 2,
            child: Material(
              color: Colors.transparent,
              shape: const CircleBorder(),
              child: InkWell(
                onTap: _avatarUploading ? null : _showAvatarSourceMenu,
                customBorder: const CircleBorder(),
                child: Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: accentColor,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white,
                      width: 3,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.12),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.photo_camera_outlined,
                    color: Colors.white,
                    size: 17,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileIdentityHeader({
    required AuthProvider auth,
    required Map<String, dynamic> profile,
  }) {
    final username = (auth.username ?? '').trim();
    final loginText = username.isEmpty ? 'user' : username;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 10),
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 14,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _buildProfileAvatar(profile),
          const SizedBox(width: 18),
          Expanded(
            child: Text(
              loginText,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w900,
                color: Color(0xFF333333),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _editProfileField({
    required String title,
    required String field,
    required String currentValue,
    required Map<String, dynamic> profile,
    required TextInputType keyboardType,
    int maxLines = 1,
  }) async {
    final parentContext = context;
    final initialEditValue =
    field == 'phone' ? _clientPhoneDigits(currentValue) : currentValue;
    final controller = TextEditingController(text: initialEditValue);
    final focusNode = FocusNode();

    bool saving = false;
    bool dirty = false;
    String? fieldError;

    final saved = await showModalBottomSheet<bool>(
      context: parentContext,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (modalContext, setModalState) {
            Future<void> requestClose() async {
              if (saving) return;

              if (!dirty) {
                if (sheetContext.mounted) {
                  Navigator.of(sheetContext).pop(false);
                }
                return;
              }

              final discard =
              await _confirmDiscardProfileChanges(sheetContext);
              if (!discard || !sheetContext.mounted) return;

              setModalState(() => dirty = false);
              Navigator.of(sheetContext).pop(false);
            }

            Future<void> save() async {
              if (saving) return;

              final newValue = controller.text.trim();
              final phoneDigits =
              field == 'phone' ? _clientPhoneDigits(newValue) : '';

              if (field == 'phone' && phoneDigits.isNotEmpty) {
                if (phoneDigits.length < 7 || phoneDigits.length > 15) {
                  setModalState(() {
                    fieldError = _avatarText(
                      ru: 'Проверьте номер телефона',
                      en: 'Check the phone number',
                      hy: 'Ստուգեք հեռախոսահամարը',
                    );
                  });
                  focusNode.requestFocus();
                  return;
                }
              }

              setModalState(() {
                saving = true;
                fieldError = null;
              });

              try {
                final phone = field == 'phone'
                    ? (phoneDigits.isEmpty ? '' : '+$phoneDigits')
                    : _normalizeClientPhone(profile['phone']);

                final address = field == 'address'
                    ? newValue
                    : profile['address']?.toString() ?? '';

                await ApiService.updateProfile(
                  phone: phone,
                  address: address,
                );

                if (!sheetContext.mounted) return;

                setModalState(() {
                  saving = false;
                  dirty = false;
                });
                Navigator.of(sheetContext).pop(true);
              } catch (_) {
                if (!sheetContext.mounted) return;

                setModalState(() {
                  saving = false;
                  fieldError = _avatarText(
                    ru: 'Не удалось сохранить. Проверьте это поле.',
                    en: 'Could not save. Please check this field.',
                    hy: 'Չհաջողվեց պահպանել։ Ստուգեք այս դաշտը։',
                  );
                });

                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (sheetContext.mounted) {
                    focusNode.requestFocus();
                  }
                });

                if (parentContext.mounted) {
                  ScaffoldMessenger.of(parentContext).showSnackBar(
                    SnackBar(
                      content: Text(
                        AppLocalizations.of(parentContext)!.profileSaveError,
                      ),
                      backgroundColor: Colors.red,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              }
            }

            return WillPopScope(
              onWillPop: () async {
                if (saving) return false;
                if (!dirty) return true;
                return _confirmDiscardProfileChanges(sheetContext);
              },
              child: Padding(
                padding: EdgeInsets.only(
                  bottom: MediaQuery.of(sheetContext).viewInsets.bottom,
                ),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(28),
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 44,
                          height: 5,
                          decoration: BoxDecoration(
                            color: Colors.black12,
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              title,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: saving ? null : requestClose,
                            tooltip: _avatarText(
                              ru: 'Закрыть',
                              en: 'Close',
                              hy: 'Փակել',
                            ),
                            icon: const Icon(Icons.close_rounded),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: controller,
                        focusNode: focusNode,
                        autofocus: true,
                        keyboardType: keyboardType,
                        inputFormatters: field == 'phone'
                            ? <TextInputFormatter>[
                          FilteringTextInputFormatter.digitsOnly,
                        ]
                            : null,
                        maxLines: maxLines,
                        textInputAction:
                        maxLines == 1 ? TextInputAction.done : null,
                        onSubmitted: maxLines == 1
                            ? (_) {
                          save();
                        }
                            : null,
                        onChanged: (value) {
                          final nextDirty = value != initialEditValue;
                          if (nextDirty != dirty || fieldError != null) {
                            setModalState(() {
                              dirty = nextDirty;
                              fieldError = null;
                            });
                          }
                        },
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: const Color(0xFFF6F6F6),
                          prefixText: field == 'phone' ? '+ ' : null,
                          prefixStyle: field == 'phone'
                              ? const TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          )
                              : null,
                          hintText: field == 'phone'
                              ? _avatarText(
                            ru: 'код страны и номер',
                            en: 'country code and number',
                            hy: 'երկրի կոդը և համարը',
                          )
                              : null,
                          errorText: fieldError,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(18),
                            borderSide: BorderSide.none,
                          ),
                          errorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(18),
                            borderSide: const BorderSide(
                              color: Colors.red,
                              width: 1.2,
                            ),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(18),
                            borderSide: const BorderSide(
                              color: Colors.red,
                              width: 1.5,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          onPressed: saving ? null : save,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accentColor,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18),
                            ),
                          ),
                          child: saving
                              ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                              : Text(
                            AppLocalizations.of(parentContext)!
                                .profileSave,
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.dispose();
      focusNode.dispose();
    });

    if (saved == true && mounted) {
      _reloadProfile();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            AppLocalizations.of(context)!.profileSaved,
          ),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: Text(
          widget.sellerMode ? l10n.organizationSettings : l10n.profile,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        actions: widget.sellerMode
            ? const []
            : const [
          _ProfileLanguageSwitcher(),
          SizedBox(width: 8),
        ],
      ),
      body: auth.isLoggedIn
          ? widget.sellerMode
          ? _buildSellerModeProfile(context)
          : _buildLoggedInProfile(context, auth)
          : _buildAuthRequiredWidget(context),
    );
  }

  Widget _buildAuthRequiredWidget(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/images/auth_bg.png'),
          fit: BoxFit.cover,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 72),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 80),
            Image.asset(
              'assets/images/logo.png',
              width: 140,
              height: 140,
            ),
            const SizedBox(height: 32),
            Text(
              l10n.welcome,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w900,
                color: Color(0xFF333333),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              l10n.loginPrompt,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 15,
                color: Color(0xFF666666),
                height: 1.4,
              ),
            ),
            const SizedBox(height: 40),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: () => _openLogin(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: accentColor,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                ),
                child: Text(
                  l10n.login,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () => _openRegister(context),
              child: Text(
                l10n.registerPrompt,
                style: const TextStyle(
                  color: accentColor,
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSellerModeProfile(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return ListView(
      padding: EdgeInsets.only(
        top: 16,
        bottom: 72 + MediaQuery.of(context).padding.bottom,
      ),
      children: [
        _buildMenuItem(
          icon: Icons.business_rounded,
          title: l10n.organizationSettings,
          onTap: () => _openSellerCompanySettings(context),
        ),
      ],
    );
  }

  Widget _buildLoggedInProfile(BuildContext context, AuthProvider auth) {
    final l10n = AppLocalizations.of(context)!;

    return RefreshIndicator(
      onRefresh: _refreshProfileData,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _profileFuture,
        builder: (context, snapshot) {
          final profile = snapshot.data ?? <String, dynamic>{};
          final phone = _normalizeClientPhone(profile['phone']);
          final address = profile['address']?.toString() ?? '';

          return ListView(
            padding: EdgeInsets.only(
              bottom: 72 + MediaQuery.of(context).padding.bottom,
            ),
            children: [
              _buildProfileIdentityHeader(
                auth: auth,
                profile: profile,
              ),

              Consumer<FavoriteProvider>(
                builder: (context, favorites, _) {
                  final count = favorites.favoriteSlugs.length;
                  return _buildMenuItem(
                    icon: Icons.favorite_border,
                    title: l10n.favorites,
                    badgeCount: count,
                    onTap: () => _openFavorites(context),
                  );
                },
              ),

              Consumer<CartProvider>(
                builder: (context, cart, _) {
                  return _buildMenuItem(
                    icon: Icons.shopping_bag_outlined,
                    title: l10n.cart,
                    subtitle: cart.totalPrice > 0
                        ? '${cart.totalPrice.toStringAsFixed(0)} \u058F'
                        : null,
                    badgeCount: cart.itemsCount,
                    onTap: () => _openCart(context),
                  );
                },
              ),

              _buildMenuItem(
                icon: Icons.receipt_long_outlined,
                title: l10n.myPurchases,
                subtitle: l10n.myPurchasesSubtitle,
                onTap: () => _openPurchases(context),
              ),

              _buildMenuItem(
                icon: Icons.rate_review_outlined,
                title: l10n.myReviews,
                subtitle: l10n.myReviewsSubtitle,
                onTap: () => _openMyReviews(context),
              ),

              _buildMenuItem(
                icon: Icons.phone_outlined,
                title: l10n.profilePhone,
                subtitle: phone.isEmpty ? l10n.profilePhoneAdd : phone,
                onTap: () => _editProfileField(
                  title: l10n.profilePhone,
                  field: 'phone',
                  currentValue: phone,
                  profile: profile,
                  keyboardType: TextInputType.phone,
                ),
              ),

              _buildMenuItem(
                icon: Icons.location_on_outlined,
                title: l10n.profileAddress,
                subtitle: address.isEmpty ? l10n.profileAddressAdd : address,
                onTap: () => _editProfileField(
                  title: l10n.profileDeliveryAddress,
                  field: 'address',
                  currentValue: address,
                  profile: profile,
                  keyboardType: TextInputType.streetAddress,
                  maxLines: 3,
                ),
              ),

              FutureBuilder<Map<String, dynamic>?>(
                future: _sellerApplicationFuture,
                builder: (context, applicationSnapshot) {
                  final application = applicationSnapshot.data;
                  if (application == null) {
                    if (auth.isSeller) return const SizedBox.shrink();
                    return _buildMenuItem(
                      icon: Icons.storefront_outlined,
                      title: l10n.becomeSeller,
                      subtitle: l10n.becomeSellerSubtitle,
                      onTap: () => _openSellerRegistration(context),
                    );
                  }
                  return _buildSellerApplicationCard(
                    context,
                    application,
                  );
                },
              ),

              if (auth.isSeller && widget.showSellerPanelEntry)
                _buildMenuItem(
                  icon: Icons.storefront_rounded,
                  title: l10n.sellerPanel,
                  subtitle: l10n.sellerPanelSubtitle,
                  onTap: () => _openSellerDashboard(context),
                ),

              const SizedBox(height: 8),
              _buildMenuItem(
                icon: Icons.logout,
                title: l10n.logout,
                color: Colors.red,
                onTap: () => _logout(context),
              ),
            ],
          );
        },
      ),
    );
  }


  Widget _buildSellerApplicationCard(
      BuildContext context,
      Map<String, dynamic> application,
      ) {
    final l10n = AppLocalizations.of(context)!;
    final status = application['status']?.toString() ?? 'draft';

    final statusDisplay = switch (status) {
      'approved' => l10n.sellerStatusApproved,
      'rejected' => l10n.sellerStatusRejected,
      'changes_requested' => l10n.sellerStatusChangesRequested,
      'pending' => l10n.sellerStatusPending,
      'draft' => l10n.sellerStatusDraft,
      _ => l10n.sellerApplication,
    };

    final comment = application['admin_comment']?.toString().trim() ?? '';
    final editable = application['is_editable'] == true;

    Color statusColor;
    IconData statusIcon;
    switch (status) {
      case 'approved':
        statusColor = const Color(0xFF2E9B55);
        statusIcon = Icons.check_circle_outline_rounded;
        break;
      case 'rejected':
        statusColor = Colors.red;
        statusIcon = Icons.cancel_outlined;
        break;
      case 'changes_requested':
        statusColor = const Color(0xFFE67E22);
        statusIcon = Icons.edit_note_rounded;
        break;
      case 'pending':
        statusColor = accentColor;
        statusIcon = Icons.schedule_rounded;
        break;
      default:
        statusColor = Colors.blueGrey;
        statusIcon = Icons.description_outlined;
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: statusColor.withOpacity(.28)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(.12),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(statusIcon, color: statusColor),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      l10n.sellerApplication,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      statusDisplay,
                      style: TextStyle(
                        color: statusColor,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (comment.isNotEmpty) ...[
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                color: const Color(0xFFF7F7F7),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    l10n.sellerApplicationChangesRequired,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 5),
                  Text(comment, style: const TextStyle(height: 1.35)),
                ],
              ),
            ),
          ],
          if (editable || status == 'approved') ...[
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              height: 46,
              child: ElevatedButton.icon(
                onPressed: () {
                  if (status == 'approved') {
                    _openSellerCompanySettings(context);
                  } else {
                    _openSellerApplication(context, application);
                  }
                },
                icon: const Icon(Icons.edit_outlined),
                label: Text(
                  status == 'approved'
                      ? l10n.organizationSettings
                      : status == 'changes_requested'
                      ? l10n.fixSellerApplication
                      : l10n.continueSellerApplication,
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: accentColor,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    String? subtitle,
    Color? color,
    int badgeCount = 0,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: ListTile(
        leading: Icon(icon, color: color ?? Colors.grey[700]),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 16,
            color: color ?? Colors.black,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: subtitle == null
            ? null
            : Text(
          subtitle,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (badgeCount > 0) ...[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.redAccent,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  badgeCount > 99 ? '99+' : '$badgeCount',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    height: 1,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 8),
            ],
            Icon(Icons.chevron_right, color: Colors.grey[400]),
          ],
        ),
        onTap: onTap,
      ),
    );
  }
}


// РџРµСЂРµРєР»СЋС‡Р°С‚РµР»СЊ СЏР·С‹РєР° Р±РµР· С„Р»Р°РіРѕРІ
class _ProfileLanguageSwitcher extends StatelessWidget {
  const _ProfileLanguageSwitcher();

  @override
  Widget build(BuildContext context) {
    final currentCode =
        context.watch<LocaleProvider>().locale.languageCode;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _ProfileLanguageButton(
          label: 'ARM',
          code: 'hy',
          selected: currentCode == 'hy',
        ),
        _ProfileLanguageButton(
          label: 'EN',
          code: 'en',
          selected: currentCode == 'en',
        ),
        _ProfileLanguageButton(
          label: 'RU',
          code: 'ru',
          selected: currentCode == 'ru',
        ),
      ],
    );
  }
}

class _ProfileLanguageButton extends StatelessWidget {
  final String label;
  final String code;
  final bool selected;

  const _ProfileLanguageButton({
    required this.label,
    required this.code,
    required this.selected,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: () => context.read<LocaleProvider>().setLocale(code),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.symmetric(horizontal: 1),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFD1BC00) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w900,
            color: selected ? Colors.white : const Color(0xFF555555),
          ),
        ),
      ),
    );
  }
}
