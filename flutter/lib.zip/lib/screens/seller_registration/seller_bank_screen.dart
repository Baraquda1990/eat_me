﻿import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../../l10n/app_localizations.dart';
import 'package:provider/provider.dart';

import '../../services/api_service.dart';
import 'seller_registration_provider.dart';
import 'seller_registration_service.dart';
import 'seller_registration_success_screen.dart';
import 'widgets/seller_registration_header.dart';
import 'widgets/seller_step_indicator.dart';

class SellerBankScreen extends StatefulWidget {
  const SellerBankScreen({super.key});
  @override
  State<SellerBankScreen> createState() => _SellerBankScreenState();
}

class _SellerBankScreenState extends State<SellerBankScreen> {
  static const _accent = Color(0xFFD1BC00);
  final _formKey = GlobalKey<FormState>();
  final _bank = TextEditingController();
  final _iban = TextEditingController();
  final _holder = TextEditingController();
  final _description = TextEditingController();
  bool _ready = false;
  bool _loading = false;
  bool _showValidationErrors = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_ready) return;
    _ready = true;
    final p = context.read<SellerRegistrationProvider>();
    _bank.text = p.bankName; _iban.text = p.iban;
    _holder.text = p.accountHolderName; _description.text = p.publicDescription;
  }

  @override
  void dispose() {
    _bank.dispose(); _iban.dispose(); _holder.dispose(); _description.dispose();
    super.dispose();
  }

  SellerRegistrationService _service() => SellerRegistrationService(
    dio: Dio(BaseOptions(connectTimeout: const Duration(seconds: 15), receiveTimeout: const Duration(seconds: 60))),
    baseUrl: ApiService.apiUrl,
  );

  String? _required(String? v) => v == null || v.trim().isEmpty ? AppLocalizations.of(context)!.requiredField : null;

  Future<void> _pickLogo() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['jpg', 'jpeg', 'png', 'webp'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final f = result.files.single;
    if (f.bytes == null) return;
    if (f.size > 10 * 1024 * 1024) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppLocalizations.of(context)!.logoTooLarge10)));
      return;
    }
    context.read<SellerRegistrationProvider>().setLogo(bytes: f.bytes!, fileName: f.name);
  }

  Future<void> _submit() async {
    if (_loading) return;

    if (!_showValidationErrors) {
      setState(() => _showValidationErrors = true);
    }

    if (!(_formKey.currentState?.validate() ?? false)) return;

    final p = context.read<SellerRegistrationProvider>();
    final id = p.applicationId;
    if (id == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppLocalizations.of(context)!.applicationNotFound)));
      return;
    }
    p.saveBankInfo(bankName: _bank.text, iban: _iban.text, accountHolderName: _holder.text, publicDescription: _description.text);
    setState(() => _loading = true);
    try {
      final service = _service();
      final saved = await service.saveBankAndBranding(
        applicationId: id,
        bankName: p.bankName,
        iban: p.iban,
        accountHolderName: p.accountHolderName,
        publicDescription: p.publicDescription,
        logoBytes: p.logoBytes,
        logoFileName: p.logoFileName,
      );
      p.applyApplicationState(saved);

      final result = await service.submitApplication(applicationId: id);
      p.applyApplicationState(result);

      if (!mounted) return;

      // Replace only the bank screen with the success screen.
      // The registration route stays in the stack until the user presses
      // "Done". When SuccessScreen closes the whole registration flow,
      // ProfileScreen's awaited Navigator.push completes and reloads
      // /seller-applications/my/ from the backend.
      await Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => SellerRegistrationSuccessScreen(
            applicationId: id,
            status: result['status']?.toString() ?? 'pending',
          ),
        ),
      );
    } on DioException catch (e) {
      if (!mounted) return;
      final msg = e.response?.data?.toString() ?? e.message ?? AppLocalizations.of(context)!.networkError;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppLocalizations.of(context)!.applicationSubmitFailed(msg)), backgroundColor: Colors.red));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppLocalizations.of(context)!.applicationSubmitFailed(e.toString())), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  InputDecoration _d(String label) => InputDecoration(
    labelText: label, filled: true, fillColor: Colors.white,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _accent, width: 1.6)),
  );

  @override
  Widget build(BuildContext context) {
    final p = context.watch<SellerRegistrationProvider>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/auth_bg.png',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const ColoredBox(color: Colors.white),
          ),
          SafeArea(
            child: Column(children: [
              SellerRegistrationHeader(onBack: () => Navigator.of(context).maybePop()),
              const SellerStepIndicator(currentStep: 5),
              const SizedBox(height: 14),
              Expanded(child: Form(
                key: _formKey,
                autovalidateMode: _showValidationErrors
                    ? AutovalidateMode.onUserInteraction
                    : AutovalidateMode.disabled,
                child: ListView(padding: const EdgeInsets.fromLTRB(20, 0, 20, 28), children: [
                  Text(AppLocalizations.of(context)!.bankDetails, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text(AppLocalizations.of(context)!.bankDetailsSubtitle, style: TextStyle(color: Colors.black54, height: 1.4)),
                  const SizedBox(height: 22),
                  TextFormField(controller: _bank, validator: _required, decoration: _d(AppLocalizations.of(context)!.bankName)),
                  const SizedBox(height: 14),
                  TextFormField(controller: _iban, validator: _required, textCapitalization: TextCapitalization.characters, decoration: _d('IBAN')),
                  const SizedBox(height: 14),
                  TextFormField(controller: _holder, validator: _required, decoration: _d(AppLocalizations.of(context)!.accountHolder)),
                  const SizedBox(height: 14),
                  TextFormField(controller: _description, minLines: 4, maxLines: 6, decoration: _d(AppLocalizations.of(context)!.companyDescriptionOptional)),
                  const SizedBox(height: 20),
                  Text(AppLocalizations.of(context)!.companyLogo, style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  if (p.logoBytes != null)
                    Row(children: [
                      ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(p.logoBytes!, width: 82, height: 82, fit: BoxFit.cover)),
                      const SizedBox(width: 12),
                      Expanded(child: Text(p.logoFileName ?? AppLocalizations.of(context)!.logo, overflow: TextOverflow.ellipsis)),
                      IconButton(onPressed: _loading ? null : p.clearLogo, icon: const Icon(Icons.delete_outline)),
                    ])
                  else
                    OutlinedButton.icon(onPressed: _loading ? null : _pickLogo, icon: const Icon(Icons.add_photo_alternate_outlined), label: Text(AppLocalizations.of(context)!.chooseLogo)),
                  const SizedBox(height: 30),
                  SizedBox(height: 54, child: ElevatedButton(
                    onPressed: _loading ? null : _submit,
                    style: ElevatedButton.styleFrom(backgroundColor: _accent, foregroundColor: Colors.white),
                    child: _loading ? const CircularProgressIndicator(color: Colors.white) : Text(AppLocalizations.of(context)!.submitApplication, style: TextStyle(fontWeight: FontWeight.w800)),
                  )),
                ]),
              )),
            ]),
          ),
        ],
      ),
    );
  }
}

