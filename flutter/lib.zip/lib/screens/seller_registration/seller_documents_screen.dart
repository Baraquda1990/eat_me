﻿import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../../l10n/app_localizations.dart';
import 'package:provider/provider.dart';

import '../../services/api_service.dart';
import 'seller_registration_provider.dart';
import 'seller_registration_service.dart';
import 'seller_bank_screen.dart';
import 'widgets/seller_registration_header.dart';
import 'widgets/seller_step_indicator.dart';

String localizedDocumentType(BuildContext context, String code) {
  final l10n = AppLocalizations.of(context)!;
  return switch (code) {
    'registration' => l10n.docRegistration,
    'tax' => l10n.docTax,
    'license' => l10n.docLicense,
    'food_safety' => l10n.docFoodSafety,
    'certificate' => l10n.docCertificate,
    'identity' => l10n.docIdentity,
    'bank' => l10n.docBank,
    _ => l10n.docOther,
  };
}


class SellerDocumentsScreen extends StatefulWidget {
  const SellerDocumentsScreen({super.key});

  @override
  State<SellerDocumentsScreen> createState() =>
      _SellerDocumentsScreenState();
}

class _SellerDocumentsScreenState extends State<SellerDocumentsScreen> {
  static const Color _accent = Color(0xFFD1BC00);

  String _selectedDocumentType = 'registration';
  bool _isUploading = false;
  bool _showDocumentsError = false;
  final List<Map<String, dynamic>> _uploadedDocuments = [];
  bool _initializedDocuments = false;


  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initializedDocuments) return;
    _initializedDocuments = true;
    final provider = context.read<SellerRegistrationProvider>();
    _uploadedDocuments.addAll(
      provider.documents.map((document) => {
        'id': document.id,
        'document_type': document.documentType,
        'original_name': document.originalName,
        'file_url': document.fileUrl,
      }),
    );
  }

  SellerRegistrationService _createService() {
    return SellerRegistrationService(
      dio: Dio(
        BaseOptions(
          connectTimeout: const Duration(seconds: 15),
          receiveTimeout: const Duration(seconds: 60),
          headers: const {'Accept': 'application/json'},
        ),
      ),
      baseUrl: ApiService.apiUrl,
    );
  }

  Future<void> _pickAndUploadDocument() async {
    if (_isUploading) return;

    final provider = context.read<SellerRegistrationProvider>();
    final applicationId = provider.applicationId;

    if (applicationId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.of(context)!.createApplicationFirst),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const [
        'pdf',
        'jpg',
        'jpeg',
        'png',
        'webp',
        'doc',
        'docx',
      ],
      withData: true,
    );

    if (result == null || result.files.isEmpty) return;

    final pickedFile = result.files.single;
    final bytes = pickedFile.bytes;

    if (bytes == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.of(context)!.fileReadFailed),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    if (pickedFile.size > 20 * 1024 * 1024) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.of(context)!.fileTooLarge20),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() => _isUploading = true);

    try {
      final uploaded = await _createService().uploadDocument(
        applicationId: applicationId,
        documentType: _selectedDocumentType,
        bytes: bytes,
        fileName: pickedFile.name,
      );

      if (!mounted) return;

      setState(() {
        _uploadedDocuments.add(uploaded);
        _showDocumentsError = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.of(context)!.documentUploaded),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } on DioException catch (e) {
      if (!mounted) return;
      final message = e.response?.data?.toString() ?? e.message ?? AppLocalizations.of(context)!.networkError;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.of(context)!.documentUploadFailed(message)),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.red,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.of(context)!.documentUploadFailed(e.toString())),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  Future<void> _deleteDocument(Map<String, dynamic> document) async {
    final id = int.tryParse(document['id'].toString());
    if (id == null) return;

    try {
      await _createService().deleteDocument(id);
      if (!mounted) return;
      setState(() => _uploadedDocuments.remove(document));
    } on DioException catch (e) {
      if (!mounted) return;
      final message = e.response?.data?.toString() ?? e.message ?? AppLocalizations.of(context)!.networkError;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppLocalizations.of(context)!.documentDeleteFailed(message))),
      );
    }
  }

  void _next() {
    if (_uploadedDocuments.isEmpty) {
      setState(() => _showDocumentsError = true);
      return;
    }

    final provider = context.read<SellerRegistrationProvider>();

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChangeNotifierProvider.value(
          value: provider,
          child: const SellerBankScreen(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/auth_bg.png',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const ColoredBox(color: Colors.white),
          ),
          SafeArea(
            child: Column(
              children: [
                SellerRegistrationHeader(
                  onBack: () => Navigator.of(context).maybePop(),
                ),
                const SellerStepIndicator(currentStep: 4),
                const SizedBox(height: 16),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                    children: [
                      Text(
                        AppLocalizations.of(context)!.documents,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        AppLocalizations.of(context)!.documentsSubtitle,
                        style: TextStyle(height: 1.4, color: Colors.black54),
                      ),
                      const SizedBox(height: 24),
                      DropdownButtonFormField<String>(
                        value: _selectedDocumentType,
                        decoration: InputDecoration(
                          labelText: AppLocalizations.of(context)!.documentType,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: const BorderSide(color: _accent),
                          ),
                        ),
                        items: const ['registration', 'tax', 'license', 'food_safety', 'certificate', 'identity', 'bank', 'other']
                            .map(
                              (entry) => DropdownMenuItem<String>(
                            value: entry,
                            child: Text(localizedDocumentType(context, entry)),
                          ),
                        )
                            .toList(),
                        onChanged: _isUploading
                            ? null
                            : (value) {
                          if (value != null) {
                            setState(() => _selectedDocumentType = value);
                          }
                        },
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 50,
                        child: OutlinedButton.icon(
                          onPressed: _isUploading ? null : _pickAndUploadDocument,
                          style: OutlinedButton.styleFrom(
                            foregroundColor: _accent,
                            side: const BorderSide(color: _accent),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          icon: _isUploading
                              ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.2,
                              color: _accent,
                            ),
                          )
                              : const Icon(Icons.upload_file_outlined),
                          label: Text(
                            _isUploading ? AppLocalizations.of(context)!.uploading : AppLocalizations.of(context)!.chooseAndUploadFile,
                          ),
                        ),
                      ),
                      if (_showDocumentsError) ...[
                        const SizedBox(height: 8),
                        Text(
                          AppLocalizations.of(context)!.uploadAtLeastOneDocument,
                          style: const TextStyle(
                            color: Colors.red,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                      const SizedBox(height: 24),
                      if (_uploadedDocuments.isNotEmpty) ...[
                        Text(
                          AppLocalizations.of(context)!.uploadedDocuments,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 10),
                        ..._uploadedDocuments.map((document) {
                          final type = document['document_type']?.toString() ?? 'other';
                          final name = document['original_name']?.toString().trim();

                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: ListTile(
                              leading: const Icon(
                                Icons.description_outlined,
                                color: _accent,
                              ),
                              title: Text(
                                name == null || name.isEmpty
                                    ? AppLocalizations.of(context)!.document
                                    : name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              subtitle: Text(localizedDocumentType(context, type)),
                              trailing: IconButton(
                                onPressed: () => _deleteDocument(document),
                                icon: const Icon(Icons.delete_outline),
                                tooltip: AppLocalizations.of(context)!.delete,
                              ),
                            ),
                          );
                        }),
                      ],
                      const SizedBox(height: 28),
                      SizedBox(
                        height: 50,
                        child: ElevatedButton(
                          onPressed: _isUploading ? null : _next,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _accent,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: Text(
                            AppLocalizations.of(context)!.next,
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

