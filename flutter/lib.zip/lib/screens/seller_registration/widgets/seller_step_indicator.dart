import 'package:flutter/material.dart';

class SellerStepIndicator extends StatelessWidget {
  const SellerStepIndicator({
    super.key,
    required this.currentStep,
  }) : assert(currentStep >= 1 && currentStep <= 5);

  final int currentStep;

  static const Color accent = Color(0xFFD1BC00);
  static const Color inactive = Color(0xFF8A8A8A);

  List<String> _labels(BuildContext context) {
    final languageCode = Localizations.localeOf(context).languageCode;

    switch (languageCode) {
      case 'hy':
        return const [
          'Տեսակ',
          'Ընկերության\nտվյալներ',
          'Կատեգորիա',
          'Փաստաթղթեր',
          'Բանկ և\nբրենդինգ',
        ];
      case 'ru':
        return const [
          'Тип',
          'Данные\nкомпании',
          'Категория',
          'Документы',
          'Банк и\nбрендинг',
        ];
      default:
        return const [
          'Type',
          'Company\ninfo',
          'Category',
          'Documents',
          'Bank &\nbranding',
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    final labels = _labels(context);
    final languageCode = Localizations.localeOf(context).languageCode;
    final labelFontSize = languageCode == 'hy' ? 8.4 : 9.5;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Row(
            children: List.generate(9, (index) {
              if (index.isOdd) {
                final segment = (index + 1) ~/ 2;
                return Expanded(
                  child: Container(
                    height: 3,
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    decoration: BoxDecoration(
                      color: segment < currentStep ? accent : inactive,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                );
              }

              final step = index ~/ 2 + 1;
              final completed = step < currentStep;
              final selected = step == currentStep;

              return AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                width: 24,
                height: 24,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: selected ? accent : Colors.white,
                  border: Border.all(
                    color: completed || selected ? accent : inactive,
                    width: 1.5,
                  ),
                ),
                child: completed
                    ? const Icon(
                  Icons.check_rounded,
                  size: 15,
                  color: accent,
                )
                    : Text(
                  '$step',
                  style: TextStyle(
                    color: selected ? Colors.white : Colors.black87,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: List.generate(labels.length, (index) {
              final selected = index + 1 == currentStep;
              return Expanded(
                child: Text(
                  labels[index],
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: labelFontSize,
                    height: 1.1,
                    color: selected ? Colors.black : inactive,
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}
